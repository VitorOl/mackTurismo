package dao;

import java.util.List;

import Model.Reserva;


public class ReservaDAO implements GenericoDAO<Reserva> {
	
	
	List<Reserva> reservas;

	@Override
	public List<Reserva> listar() {
		
		
		return reservas;
		
	}

	@Override
	public void inserir(Reserva r) {
		reservas.add(r);
		
	}

	@Override
	public void alterar(Reserva r) {
		for(int i=0;i<reservas.size();i++){
			if(reservas.get(i).equals(r)){
				reservas.add(i, r);;
			}
			
		}
		
	}

	@Override
	public void remover(Reserva r) {
			for(int i=0;i<reservas.size();i++){
				if(reservas.get(i).equals(r)){
					reservas.remove(i);
				}	
			}
		}
		
}
