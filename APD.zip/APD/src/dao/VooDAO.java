package dao;

import java.util.List;

import Model.Voo;

public class VooDAO implements GenericoDAO<Voo> {
	List<Voo>voos;

	@Override
	public List<Voo> listar() {
		return voos;
	}

	@Override
	public void inserir(Voo v) {
		voos.add(v);
		
	}

	@Override
	public void alterar(Voo v) {
		
		for(int i=0;i<voos.size();i++){
			if(voos.get(i).equals(v)){
				voos.add(i, v);
			}
			}
	}

	@Override
	public void remover(Voo v) {
		for(int i=0;i<voos.size();i++){
			if(voos.get(i).equals(v)){
				voos.remove(i);
			}	
		}
		
	}
	

}
