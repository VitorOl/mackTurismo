package Model;

import java.util.Date;

public class Voo {
	
	private Date data;	
	private double valorTotal;
	
	private static final int assentoPrimeiraClasse = 10;
	private static final int assentoExecutivo = 20;
	private static final int assentoEconomico = 70;
	
	private int[] totalAssentos;
	private int contAssentos;
	
	private double valor;
	
	public enum ClassesVoo {
		ECONOMICA("economica"),
		EXECUTIVA("executiva"),
		PRIMEIRA_CLASSE("primeira");

		String tipo;
		
		ClassesVoo(String tipo){
			this.tipo = tipo;
		}

			public String getTipo() {
				return tipo;
			}
}
	
	
	public Voo (Date data, String classeVoo, ListaDeVoos vooDesejado, int assento) {
		this.data = data;
		this.totalAssentos = new int[100];
		if(classeVoo=="economica"){
			ClassesVoo classe = ClassesVoo.ECONOMICA;
			String classeAssento = classe.getTipo();
			valor = 1.000;
		}else if(classeVoo=="executiva"){
			ClassesVoo classe = ClassesVoo.EXECUTIVA;
			String classeAssento = classe.getTipo();
			valor = 2.000;
		}else{
			ClassesVoo classe = ClassesVoo.PRIMEIRA_CLASSE;
			String classeAssento = classe.getTipo();
			valor = 3.000;
		}
		
	}
	
	public void addPassageiro(){
		
		
	}
	
	

	
	
}
