package Model;

public class Passagem {

	
}
