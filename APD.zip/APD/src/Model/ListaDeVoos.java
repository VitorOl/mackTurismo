package Model;

import java.util.ArrayList;
import java.util.List;

public class ListaDeVoos {
	
	private List<Voo> listaDeVoos;
	double valor=0;
	
	public ListaDeVoos() {
		
	}
	

	
}
